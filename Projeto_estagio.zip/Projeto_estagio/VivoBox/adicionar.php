<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Adicionar RB</title>
</head>
<body class="adicionar">

    <h4><a href="index.php">Voltar</a></h4>

    <form action="salvar.php" method="POST">
        <label for="tipo">TIPO</label>
        <input type="text" name="tipo" id="tipo" placeholder="Tipo">

        <label for="marca">MARCA</label>
        <input type="text" name="marca" id="marca" placeholder="Marca">

        <label for="modelo">MODELO</label>
        <input type="text" name="modelo" id="modelo" placeholder="Modelo">

        <label for="serial">SERIAL</label>
        <input type="text" name="serial" id="serial" placeholder="Serial">

        <label for="ssdi">SSDI</label>
        <input type="text" name="ssdi" id="ssdi" placeholder="SSDI">

        <label for="senha">SENHA</label>
        <input type="text" name="senha" id="senha" placeholder="senha">

        <label for="imei_equip">IMEI DO EQUIPAMENTO</label>
        <input type="text" name="imei_equip" id="imei_equip" placeholder="imei_equip">

        <label for="imei_chip">IMEI DO CHIP</label>
        <input type="text" name="imei_chip" id="imei_chip" placeholder="imei_chip">

        <label for="login_adm">LOGIN ADM</label>
        <input type="text" name="login_adm" id="login_adm" placeholder="login_adm">

        <label for="senha_adm">SENHA DO ADM</label>
        <input type="text" name="senha_adm" id="senha_adm" placeholder="senha_adm">

        <label for="numero_linha">NUMERO DA LINHA</label>
        <input type="text" name="numero_linha" id="numero_linha" placeholder="numero_linha">

        <label for="obs">OBSERVAÇÃO</label>
        <input type="text" name="obs" id="obs" placeholder="Observação">

        <label for="data_entrada">DATA DE ENTRADA</label>
        <input type="date" name="data_entrada" id="data_entrada" required>

        <label for="data_saida">DATA DE SAÍDA</label>
        <input type="date" name="data_saida" id="data_saida">

        <label for="motivo_saida">MOTIVO DA SAÍDA</label>
        <input type="text" name="motivo_saida" id="motivo_saida" placeholder="Motivo da Saída">

    
        <input type="hidden" name="categoria" value="vivobox">

        <button id="adicionar" type="submit">Adicionar Produto</button>
    </form>

</body>
</html>
