<?php
session_start();
include "conexao.php";
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>ESTOQUE - VivoBox</title>
</head>
<body>

    <nav>
        <h1>ESTOQUE - VivoBox</h1>
    </nav>

    <h3>
        <a href="../index.php">Voltar</a>
        <a href="adicionar.php">Adicionar VivoBox</a>
    </h3>

    <?php
        // Buscar apenas os equipamentos da categoria 'vivobox'
        $sql = "SELECT * FROM equipamento WHERE categoria = 'vivobox'";
        $result = mysqli_query($conexao, $sql);

        if (!$result) {
            die("Erro ao buscar dados: " . mysqli_error($conexao));
        }
    ?>

    <table border="1px solid black">
        <tr>
            <th>Tipo</th>
            <th>Marca</th>
            <th>Modelo</th>
            <th>Serial</th>
            <th>ssdi</th>
            <th>senha</th>
            <th>IMEI Equipamento</th>
            <th>IMEI CHIP</th>
            <th>Login ADM</th>
            <th>Senha ADM</th>
            <th>Número Linha</th>
            <th>Data de Entrada</th>
            <th>Data de Saída</th>
            <th>Motivo de Saída</th>
            <th>Opções</th>
        </tr>

        <?php while ($row = mysqli_fetch_assoc($result)) : ?>
            <tr>
                <td><?= htmlspecialchars($row['tipo']) ?></td>
                <td><?= htmlspecialchars($row['marca']) ?></td>
                <td><?= htmlspecialchars($row['modelo']) ?></td>
                <td><?= htmlspecialchars($row['serial']) ?></td>
                <td><?= htmlspecialchars($row['ssdi']) ?></td>
                <td><?= htmlspecialchars($row['senha_wifi']) ?></td>
                <td><?= htmlspecialchars($row['imei_equip']) ?></td>
                <td><?= htmlspecialchars($row['imei_chip']) ?></td>
                <td><?= htmlspecialchars($row['login_adm']) ?></td>
                <td><?= htmlspecialchars($row['senha_adm']) ?></td>
                <td><?= htmlspecialchars($row['numero_linha']) ?></td>
                <td><?= htmlspecialchars($row['obs']) ?></td>

                <td>
                    <?= $row['data_entrada'] ? date("d/m/Y", strtotime($row['data_entrada'])) : "Em estoque" ?>
                </td>
                <td>
                    <?= $row['data_saida'] ? date("d/m/Y", strtotime($row['data_saida'])) : "Em estoque" ?>
                </td>

                <td><?= htmlspecialchars($row['motivo_saida']) ?></td>
                <td>
                    <a href="editar.php?id=<?= urlencode($row['id_equip']) ?>">Editar</a> |

                    <form action="salvar.php" method="POST" style="display: inline;">
                        <input type="hidden" name="id" value="<?= htmlspecialchars($row['id_equip']) ?>">
                        <button type="submit" name="excluir" onclick="return confirm('Tem certeza que deseja excluir?');">
                            Excluir
                        </button>
                    </form>
                </td>
            </tr>
        <?php endwhile; ?>
    </table>

    <?php mysqli_close($conexao); ?>

</body>
</html>
