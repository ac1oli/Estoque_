<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Document</title>
</head>
<body>
    <a href="./RB/indexrb.php">RB</a>
    <a href="./VivoBox/index.php">VivoBok</a>
    <a href="./Celular/indexcel.php">Celular</a>
    <a href="./Chip/indexchip.php">Chips Celular</a>
    <a href="./Notebook/indexnot.php">Notebook</a>
</body>
</html>