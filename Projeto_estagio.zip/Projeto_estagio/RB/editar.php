<?php
include "conexao.php";

if (isset($_GET["id"])) {
    $id = $_GET["id"];

    $sql_select = "SELECT * FROM equipamento WHERE id_equip = ? AND categoria = 'rb'";
    $stmt_select = mysqli_prepare($conexao, $sql_select);
    mysqli_stmt_bind_param($stmt_select, "i", $id);
    mysqli_stmt_execute($stmt_select);
    $result = mysqli_stmt_get_result($stmt_select);
    $dados_antigos = mysqli_fetch_assoc($result);
    mysqli_stmt_close($stmt_select);

    if (!$dados_antigos) {
        die("Erro: Registro não encontrado!");
    }
} else {
    die("Erro: ID não encontrado na URL!");
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Editar RB</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h2>Editar Registro - RB</h2>
    <form action="salvar.php" method="post">
        <input type="hidden" name="id" value="<?= $dados_antigos['id_equip'] ?>">

        Tipo: <input type="text" name="tipo" value="<?= htmlspecialchars($dados_antigos['tipo']) ?>"><br>
        Marca: <input type="text" name="marca" value="<?= htmlspecialchars($dados_antigos['marca']) ?>"><br>
        Modelo: <input type="text" name="modelo" value="<?= htmlspecialchars($dados_antigos['modelo']) ?>"><br>
        Serial: <input type="text" name="serial" value="<?= htmlspecialchars($dados_antigos['serial']) ?>"><br>
        MAC: <input type="text" name="mac" value="<?= htmlspecialchars($dados_antigos['mac']) ?>"><br>
        OBS: <input type="text" name="obs" value="<?= htmlspecialchars($dados_antigos['obs']) ?>"><br>
        Data Entrada: <input type="date" name="data_entrada" value="<?= $dados_antigos['data_entrada'] ?>"><br>
        Data Saída: <input type="date" name="data_saida" value="<?= $dados_antigos['data_saida'] ?>"><br>
        Motivo Saída: <input type="text" name="motivo_saida" value="<?= htmlspecialchars($dados_antigos['motivo_saida']) ?>"><br>

        <button type="submit" name="editar">Atualizar</button>
    </form>
</body>
</html>
