<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Adicionar RB</title>
</head>
<body class="adicionar">

    <h4><a href="indexrb.php">Voltar</a></h4>

    <form action="salvar.php" method="POST">
        <label for="tipo">TIPO</label>
        <input type="text" name="tipo" id="tipo" placeholder="Tipo">

        <label for="marca">MARCA</label>
        <input type="text" name="marca" id="marca" placeholder="Marca">

        <label for="modelo">MODELO</label>
        <input type="text" name="modelo" id="modelo" placeholder="Modelo">

        <label for="serial">SERIAL</label>
        <input type="text" name="serial" id="serial" placeholder="Serial">

        <label for="mac">MAC</label>
        <input type="text" name="mac" id="mac" placeholder="MAC">

        <label for="obs">OBSERVAÇÃO</label>
        <input type="text" name="obs" id="obs" placeholder="Observação">

        <label for="data_entrada">DATA DE ENTRADA</label>
        <input type="date" name="data_entrada" id="data_entrada" required>

        <label for="data_saida">DATA DE SAÍDA</label>
        <input type="date" name="data_saida" id="data_saida">

        <label for="motivo_saida">MOTIVO DA SAÍDA</label>
        <input type="text" name="motivo_saida" id="motivo_saida" placeholder="Motivo da Saída">

        <input type="hidden" name="categoria" value="rb">

        <button id="adicionar" type="submit">Adicionar Produto</button>
    </form>

</body>
</html>
