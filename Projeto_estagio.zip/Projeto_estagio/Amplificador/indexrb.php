<?php
session_start();
include "conexao.php";
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <title>ESTOQUE - RB</title>
</head>
<body>

    <nav>
        <h1>ESTOQUE - RB</h1>
    </nav>

    <h3>
        <a href="../index.php">Voltar</a>
        <a href="adicionar.php">Adicionar RB</a>
    </h3>

    <?php
        // Buscar apenas os equipamentos da categoria 'rb'
        $sql = "SELECT * FROM equipamento WHERE categoria = 'rb'";
        $result = mysqli_query($conexao, $sql);

        if (!$result) {
            die("Erro ao buscar dados: " . mysqli_error($conexao));
        }
    ?>

    <table border="1px solid black">
        <tr>
            <th>Tipo</th>
            <th>Marca</th>
            <th>Modelo</th>
            <th>Serial</th>
            <th>MAC</th>
            <th>OBS</th>
            <th>Data de Entrada</th>
            <th>Data de Saída</th>
            <th>Motivo de Saída</th>
            <th>Opções</th>
        </tr>

        <?php while ($row = mysqli_fetch_assoc($result)) : ?>
            <tr>
                <td><?= htmlspecialchars($row['tipo']) ?></td>
                <td><?= htmlspecialchars($row['marca']) ?></td>
                <td><?= htmlspecialchars($row['modelo']) ?></td>
                <td><?= htmlspecialchars($row['serial']) ?></td>
                <td><?= htmlspecialchars($row['mac']) ?></td>
                <td><?= htmlspecialchars($row['obs']) ?></td>

                <td>
                    <?= $row['data_entrada'] ? date("d/m/Y", strtotime($row['data_entrada'])) : "Em estoque" ?>
                </td>
                <td>
                    <?= $row['data_saida'] ? date("d/m/Y", strtotime($row['data_saida'])) : "Em estoque" ?>
                </td>

                <td><?= htmlspecialchars($row['motivo_saida']) ?></td>
                <td>
                    <a href="editar.php?id=<?= urlencode($row['id_equip']) ?>">Editar</a> |

                    <form action="salvar.php" method="POST" style="display: inline;">
                        <input type="hidden" name="id" value="<?= htmlspecialchars($row['id_equip']) ?>">
                        <button type="submit" name="excluir" onclick="return confirm('Tem certeza que deseja excluir?');">
                            Excluir
                        </button>
                    </form>
                </td>
            </tr>
        <?php endwhile; ?>
    </table>

    <?php mysqli_close($conexao); ?>

</body>
</html>
