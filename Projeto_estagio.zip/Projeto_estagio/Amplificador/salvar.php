<?php
include "conexao.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST["id"] ?? NULL;
    $tipo = $_POST["tipo"] ?? NULL;
    $marca = $_POST["marca"] ?? NULL;
    $modelo = $_POST["modelo"] ?? NULL;
    $serial = $_POST["serial"] ?? NULL;
    $mac = $_POST["mac"] ?? NULL;
    $obs = $_POST["obs"] ?? NULL;
    $data_entrada = $_POST["data_entrada"] !== "" ? $_POST["data_entrada"] : NULL;
    $data_saida = $_POST["data_saida"] !== "" ? $_POST["data_saida"] : NULL;
    $motivo_saida = $_POST["motivo_saida"] ?? NULL;

    $categoria = 'rb'; // fixa a categoria

    if (!$id) {
        $sql = "INSERT INTO equipamento 
            (tipo, categoria, marca, modelo, serial, mac, obs, data_entrada, data_saida, motivo_saida) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        if ($stmt = mysqli_prepare($conexao, $sql)) {
            mysqli_stmt_bind_param($stmt, "ssssssssss", $tipo, $categoria, $marca, $modelo, $serial, $mac, $obs, $data_entrada, $data_saida, $motivo_saida);

            if (mysqli_stmt_execute($stmt)) {
                header('Location: indexrb.php');
                exit;
            } else {
                echo "Erro ao inserir: " . mysqli_error($conexao);
            }
            mysqli_stmt_close($stmt);
        }
    }

    if (isset($_POST["editar"]) && $id) {
        $sql_select = "SELECT * FROM equipamento WHERE id_equip = ?";
        if ($stmt_select = mysqli_prepare($conexao, $sql_select)) {
            mysqli_stmt_bind_param($stmt_select, "i", $id);
            mysqli_stmt_execute($stmt_select);
            $result = mysqli_stmt_get_result($stmt_select);
            $dados_antigos = mysqli_fetch_assoc($result);
            mysqli_stmt_close($stmt_select);

            if (!$dados_antigos) {
                die("Erro: Registro não encontrado!");
            }

            $tipo = $tipo !== "" ? $tipo : $dados_antigos["tipo"];
            $marca = $marca !== "" ? $marca : $dados_antigos["marca"];
            $modelo = $modelo !== "" ? $modelo : $dados_antigos["modelo"];
            $serial = $serial !== "" ? $serial : $dados_antigos["serial"];
            $mac = $mac !== "" ? $mac : $dados_antigos["mac"];
            $obs = $obs !== "" ? $obs : $dados_antigos["obs"];
            $data_entrada = $data_entrada !== NULL ? $data_entrada : $dados_antigos["data_entrada"];
            $data_saida = $data_saida !== NULL ? $data_saida : $dados_antigos["data_saida"];
            $motivo_saida = $motivo_saida !== "" ? $motivo_saida : $dados_antigos["motivo_saida"];

            $sql_update = "UPDATE equipamento 
                SET tipo = ?, marca = ?, modelo = ?, serial = ?, mac = ?, obs = ?, data_entrada = ?, data_saida = ?, motivo_saida = ? 
                WHERE id_equip = ? AND categoria = ?";

            if ($stmt_update = mysqli_prepare($conexao, $sql_update)) {
                mysqli_stmt_bind_param($stmt_update, "sssssssssis", $tipo, $marca, $modelo, $serial, $mac, $obs, $data_entrada, $data_saida, $motivo_saida, $id, $categoria);

                if (mysqli_stmt_execute($stmt_update)) {
                    header('Location: indexrb.php');
                    exit;
                } else {
                    echo "Erro ao editar: " . mysqli_error($conexao);
                }
                mysqli_stmt_close($stmt_update);
            }
        }
    }

    if (isset($_POST["excluir"]) && $id) {
        $sql_check = "SELECT * FROM equipamento WHERE id_equip = ? AND categoria = ?";
        if ($stmt_check = mysqli_prepare($conexao, $sql_check)) {
            mysqli_stmt_bind_param($stmt_check, "is", $id, $categoria);
            mysqli_stmt_execute($stmt_check);
            $result_check = mysqli_stmt_get_result($stmt_check);
            if (mysqli_num_rows($result_check) == 0) {
                die("Erro: Registro não encontrado!");
            }
            mysqli_stmt_close($stmt_check);
        }

        $sql_delete = "DELETE FROM equipamento WHERE id_equip = ? AND categoria = ?";
        if ($stmt_delete = mysqli_prepare($conexao, $sql_delete)) {
            mysqli_stmt_bind_param($stmt_delete, "is", $id, $categoria);

            if (mysqli_stmt_execute($stmt_delete)) {
                header('Location: indexrb.php');
                exit;
            } else {
                echo "Erro ao excluir: " . mysqli_error($conexao);
            }
            mysqli_stmt_close($stmt_delete);
        }
    }

    mysqli_close($conexao);
}
?>
